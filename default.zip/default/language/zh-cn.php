<?php

return array(
    'theme_name'     => 'Default主题',
    'view'           => '浏览',
    'comment_list'   => '评论列表',
    'comment_post_on'=> '发布于',
    'reply'          => '回复该评论',
    'add_reply'      => '发表评论',
    'cancel_reply'   => '取消回复',
    'reply_notice'   => '◎欢迎参与讨论，请在这里发表您的看法、交流您的观点。',
);
